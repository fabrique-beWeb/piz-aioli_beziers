<?php

namespace Pizza\Service;
 
interface ControllerServiceInterface
{
   public function getService();
}
